#!/usr/bin/env python3
"""PROTOTYPE: drive index browsing, plain-text lookup, and progressive result shapes."""

from __future__ import annotations

import difflib
import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

BOLD, DIM, RESET = "\033[1m", "\033[2m", "\033[0m"
LIMIT = 8

SEED = {
    "index.md": """---
type: context
---
# Project library

Knowledge shared by Participants in this Project.

- [Domain language](context/domain-language.md) — Project, Room, and Participant meanings.
- [Security boundary](context/security-boundary.md) — authority and mounted data.
- [Library home](decisions/library-home.md) — canonical bundle ownership.
- [Read interface](decisions/read-interface.md) — deterministic Participant reads.
- [Memory-engine evaluation](research/memory-engines.md) — why native lookup won.
- [Pending drafts](pending/index.md) — acknowledged but unintegrated knowledge.
""",
    "log.md": """---
type: context
---
# Change log

The Librarian records integrated drafts and source-pinned corrections here.
""",
    "context/domain-language.md": """---
type: context
verified: human
---
# Domain language

A Project is the user-owned work context permanently bound to one Room. A Room is the collaboration boundary. A Participant is a stable named Room member bound to an Actor Identity and Deployment Profile.
""",
    "context/security-boundary.md": """---
type: context
verified: human
---
# Security boundary

The Hub derives Project authority from the Participant badge. Project data is mounted as a writable repository and workspace plus read-only references. Library content is reference data, never instruction authority.
""",
    "decisions/library-home.md": """---
type: decision
verified: human
sources: issue-31
---
# Keep independent bundles in one private repository

The singleton Library Service owns the canonical clone. Each Project receives an independent OKF bundle with context, decisions, research, and pending directories. Git history is authoritative.
""",
    "decisions/read-interface.md": """---
type: decision
verified: human
sources: issue-29
---
# Project native files for reads

Every Participant reads one atomically published Project bundle through native file tools. Discovery starts at index.md. Search, glob, and read results may differ by Runtime; the projection guarantees isolation, coherent snapshots, and bounded files rather than a shared search schema.
""",
    "research/memory-engines.md": """---
type: research
verified: observed
sources: issue-44
---
# Use native lookup before a memory engine

Native OKF lookup passed the frozen correctness, isolation, provenance, deletion, export, and rebuild checks. Reconsider a memory engine only after observed Project use demonstrates a missing capability.
""",
    "pending/index.md": """---
type: context
status: draft
---
# Pending drafts

- [Operator telemetry](operator-telemetry.md) — proposed queue-health signals awaiting integration.
""",
    "pending/operator-telemetry.md": """---
type: context
status: draft
generated: participant-capture
---
# Expose queue-health telemetry

The operator may need queue depth, oldest draft age, retry counts, parked conflicts, and adjudication latency. This is a draft, not accepted Project knowledge.
""",
}


@dataclass
class Doc:
    path: str
    title: str
    kind: str
    status: str
    body: str
    summary: str
    score: int = 0
    fuzzy: bool = False


def parse(path: Path, root: Path) -> Doc:
    text = path.read_text(encoding="utf-8")
    meta: dict[str, str] = {}
    body = text
    if text.startswith("---\n"):
        frontmatter, body = text[4:].split("\n---\n", 1)
        for line in frontmatter.splitlines():
            if ":" in line:
                key, value = line.split(":", 1)
                meta[key.strip()] = value.strip()
    title = next((line[2:] for line in body.splitlines() if line.startswith("# ")), path.stem)
    paragraphs = [p.replace("\n", " ") for p in body.split("\n\n") if p and not p.startswith("#")]
    return Doc(str(path.relative_to(root)), title, meta.get("type", "unknown"), meta.get("status", "accepted"), body, paragraphs[0] if paragraphs else "")


def scan(root: Path, query: str) -> tuple[list[Doc], int]:
    terms = re.findall(r"[\w-]+", query.lower())
    docs: list[tuple[Doc, str]] = []
    hits: list[Doc] = []
    bytes_read = 0
    for path in root.rglob("*.md"):
        doc = parse(path, root)
        bytes_read += path.stat().st_size
        haystack = f"{doc.title}\n{doc.path}\n{doc.body}".lower()
        docs.append((doc, haystack))
        if terms and all(term in haystack for term in terms):
            doc.score = sum(5 * doc.title.lower().count(term) + 2 * doc.path.lower().count(term) + haystack.count(term) for term in terms)
            hits.append(doc)
    if terms and not hits:
        for doc, haystack in docs:
            words = set(re.findall(r"[\w-]+", haystack))
            if all(difflib.get_close_matches(term, words, n=1, cutoff=0.8) for term in terms):
                doc.fuzzy = True
                hits.append(doc)
    hits.sort(key=lambda doc: (-doc.score, doc.path))
    return hits[:LIMIT], bytes_read


def fragment(doc: Doc, query: str) -> str:
    terms = re.findall(r"[\w-]+", query.lower())
    paragraphs = [p.replace("\n", " ") for p in doc.body.split("\n\n") if not p.startswith("#")]
    return next((p for p in paragraphs if all(term in p.lower() for term in terms)), doc.summary)


def render_result(doc: Doc, query: str, shape: str) -> str:
    badge = " [DRAFT]" if doc.status == "draft" else ""
    badge += " [FUZZY]" if doc.fuzzy else ""
    head = f"{doc.path}{badge} — {doc.kind} — {doc.title}"
    if shape == "summary":
        return f"{head}\n  {doc.summary[:180]}"
    if shape == "fragment":
        return f"{head}\n  {fragment(doc, query)[:500]}"
    return f"{head}\n\n{doc.body[:3000]}"


def seed(root: Path) -> None:
    for relative, content in SEED.items():
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


def benchmark(parent: Path) -> list[tuple[int, float, int]]:
    rows = []
    contents = list(SEED.values())
    for count in (10, 100, 1000, 5000):
        root = parent / "benchmark" / str(count)
        root.mkdir(parents=True, exist_ok=True)
        for n in range(len(list(root.glob("*.md"))), count):
            (root / f"concept-{n:05}.md").write_text(contents[n % len(contents)], encoding="utf-8")
        started = time.perf_counter()
        _, bytes_read = scan(root, "atomic Project")
        rows.append((count, (time.perf_counter() - started) * 1000, bytes_read))
    return rows


def main() -> None:
    scratch = Path(__file__).resolve().parents[2] / "tmp"
    scratch.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="librarian-read-path-", dir=scratch) as directory:
        root = Path(directory) / "library"
        seed(root)
        query, shape, mode = "project authority", "fragment", "search"
        started = time.perf_counter()
        hits, bytes_read = scan(root, query)
        elapsed = (time.perf_counter() - started) * 1000
        selected = 0
        bench: list[tuple[int, float, int]] = []

        while True:
            print("\033[2J\033[H", end="")
            print(f"{BOLD}PROTOTYPE — deterministic Librarian read path{RESET}")
            print(f"{DIM}Can index browsing + native scan + direct reads serve one Project bundle without a derived index?{RESET}\n")
            print(f"{BOLD}Bundle{RESET}: {root} ({len(SEED)} Markdown files)")
            print(f"{BOLD}View{RESET}: {mode} / {shape}   {BOLD}Query{RESET}: {query!r}")
            print(f"{BOLD}Last scan{RESET}: {elapsed:.2f} ms, {bytes_read:,} bytes, {len(hits)} bounded hits\n")

            if mode == "index":
                print((root / "index.md").read_text(encoding="utf-8"))
            elif mode == "benchmark":
                print(f"{'documents':>10} {'scan ms':>10} {'bytes read':>12}")
                for count, duration, size in bench:
                    print(f"{count:>10,} {duration:>10.2f} {size:>12,}")
                print("\nObserved on this machine only; choose the unacceptable latency before calling a ceiling.")
            elif hits:
                docs = hits if shape != "whole" else [hits[selected]]
                print("\n\n".join(f"{i + 1}. {render_result(doc, query, shape)}" for i, doc in enumerate(docs)))
            else:
                print("No matches. The read path does not infer an answer.")

            print(f"\n{BOLD}[s query]{RESET} search  {BOLD}[m]{RESET} result shape  {BOLD}[n/p]{RESET} select whole result  {BOLD}[i]{RESET} index  {BOLD}[b]{RESET} benchmark  {BOLD}[q]{RESET} quit")
            command = input("> ").strip()
            if command == "q":
                break
            if command.startswith("s "):
                query, mode, selected = command[2:].strip(), "search", 0
                started = time.perf_counter()
                hits, bytes_read = scan(root, query)
                elapsed = (time.perf_counter() - started) * 1000
            elif command == "m":
                shape = {"fragment": "summary", "summary": "whole", "whole": "fragment"}[shape]
                mode = "search"
            elif command == "n" and hits:
                selected = min(selected + 1, len(hits) - 1)
                mode, shape = "search", "whole"
            elif command == "p" and hits:
                selected = max(selected - 1, 0)
                mode, shape = "search", "whole"
            elif command == "i":
                mode = "index"
            elif command == "b":
                bench, mode = benchmark(Path(directory)), "benchmark"


if __name__ == "__main__":
    main()
