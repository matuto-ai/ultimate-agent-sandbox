# PROTOTYPE — deterministic Librarian read path

This throwaway prototype asks whether a Participant can discover and query one projected Project OKF bundle with only `index.md`, native text scanning, and direct file reads, while keeping drafts and result size obvious. Literal substring matching runs first; typo-tolerant fuzzy matching runs only when it finds nothing and labels its results. It deliberately does not implement SQLite FTS, embeddings, a shared search schema, or production code.

Run:

```sh
python3 /project/workspace/prototypes/librarian-read-path/demo.py
```

Try a broad query such as `project authority`, a draft-only query such as `telemetry`, a typo such as `telemety`, and each result shape. Fragment is the default, followed by summary and whole-document views. Run the benchmark to compare scan time as the file count grows. The seeded bundle uses decisions and language from this Project; it is created in a temporary directory and deleted on exit.
